package com.devcalc.exception;

public class DivisionByZeroException extends Exception {

    public DivisionByZeroException(String message) {
        super(message);
    }
}
